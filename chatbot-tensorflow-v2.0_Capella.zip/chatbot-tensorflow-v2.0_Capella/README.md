# chatbot-tensorflow-v2.0

This is a chatbot which works with tensorflow 2.1 and higher. I have tested it on tensorflow 2.3.0 and 2.1.0<br>
It also saves wrong answers with predicted category in a text file named as 'exceptions.txt'

Requirements:<br>
-Tensorflow 2.0 or higher<br>
-Nltk<br>
-Punkt from nltk &nbsp;&nbsp;&nbsp;&nbsp; (nltk.download('punkt'))

NOTE: This json dataset is taken from the internet, credits to the creator

